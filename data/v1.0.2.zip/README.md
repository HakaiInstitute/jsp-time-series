# jsp-data
This repository is for storing and version controlling the Hakai Institue Juvenile Salmon Programd Data in a relational set of .csv files. The data in this repo are considered the 'master' version of the Hakai JSP database.
